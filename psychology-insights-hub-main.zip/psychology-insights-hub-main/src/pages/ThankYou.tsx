import { useSearchParams, Link } from "react-router-dom";
import { CheckCircle } from "lucide-react";

export default function ThankYou() {
  const [params] = useSearchParams();
  const orderNumber = params.get("order");

  return (
    <div className="min-h-screen bg-background flex items-center justify-center px-4">
      <div className="max-w-md text-center space-y-6">
        <CheckCircle className="w-20 h-20 text-success mx-auto" />
        <h1 className="text-3xl md:text-4xl font-bold text-foreground">
          অর্ডার সফল হয়েছে!
        </h1>
        {orderNumber && (
          <p className="text-xl font-inter font-semibold text-primary">
            অর্ডার নম্বর: {orderNumber}
          </p>
        )}
        <div className="bg-card rounded-xl p-6 border border-primary/10 text-left space-y-3 text-foreground/90">
          <p>✅ আপনার অর্ডারটি সফলভাবে গ্রহণ করা হয়েছে।</p>
          <p>⏳ আমরা আপনার পেমেন্ট ভেরিফাই করছি। সাধারণত ১-৩ ঘণ্টার মধ্যে ইবুক আপনার ইমেইলে পাঠিয়ে দেওয়া হবে।</p>
          <p>📧 সর্বোচ্চ ২৪ ঘণ্টা সময় লাগতে পারে।</p>
          <p>❓ কোনো সমস্যা হলে আমাদের সাথে যোগাযোগ করুন।</p>
        </div>
        <Link
          to="/"
          className="inline-block text-primary underline underline-offset-4 hover:brightness-110"
        >
          হোমপেজে ফিরে যান
        </Link>
      </div>
    </div>
  );
}
