import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";

interface BlogPost {
  id: string;
  title: string;
  slug: string;
  content: string;
  excerpt: string | null;
  cover_image_url: string | null;
  published_at: string | null;
}

export default function BlogDetail() {
  const { slug } = useParams<{ slug: string }>();
  const [post, setPost] = useState<BlogPost | null>(null);
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);

  useEffect(() => {
    async function fetchPost() {
      const { data, error } = await supabase
        .from("blog_posts")
        .select("*")
        .eq("slug", slug)
        .single();

      if (error || !data) {
        setNotFound(true);
      } else {
        setPost(data);
      }
      setLoading(false);
    }
    fetchPost();
  }, [slug]);

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <p className="text-muted-foreground">লোড হচ্ছে...</p>
      </div>
    );
  }

  if (notFound || !post) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center px-4">
        <div className="text-center space-y-4">
          <h1 className="text-4xl font-bold text-foreground">৪০৪</h1>
          <p className="text-muted-foreground">এই পোস্টটি পাওয়া যায়নি।</p>
          <Link to="/" className="text-primary underline underline-offset-4">হোমপেজে ফিরে যান</Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background py-12 px-4">
      <article className="container max-w-3xl mx-auto space-y-8">
        <Link to="/" className="text-primary text-sm underline underline-offset-4">← হোমপেজে ফিরুন</Link>
        {post.cover_image_url && (
          <img src={post.cover_image_url} alt={post.title} className="w-full rounded-xl" loading="lazy" />
        )}
        <h1 className="text-3xl md:text-4xl font-bold text-foreground">{post.title}</h1>
        {post.published_at && (
          <p className="text-muted-foreground text-sm font-inter">
            {new Date(post.published_at).toLocaleDateString("bn-BD")}
          </p>
        )}
        <div
          className="prose prose-invert max-w-none text-foreground/90 leading-relaxed text-lg"
          dangerouslySetInnerHTML={{ __html: post.content }}
        />
      </article>
    </div>
  );
}
