import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { supabase } from "@/integrations/supabase/client";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import GoldCTA from "@/components/GoldCTA";

const checkoutSchema = z.object({
  full_name: z.string().trim().min(2, "নাম লিখুন").max(100),
  email: z.string().trim().email("সঠিক ইমেইল দিন").max(255),
  phone: z.string().trim().min(11, "সঠিক ফোন নম্বর দিন").max(15),
  payment_method: z.enum(["bkash", "nagad", "rocket"], { required_error: "পেমেন্ট মেথড সিলেক্ট করুন" }),
  transaction_id: z.string().trim().min(4, "Transaction ID দিন").max(50),
});

type CheckoutForm = z.infer<typeof checkoutSchema>;

const paymentNumbers: Record<string, string> = {
  bkash: "01842081088",
  nagad: "01842081088",
  rocket: "01842081088",
};

export default function Checkout() {
  const navigate = useNavigate();
  const [submitting, setSubmitting] = useState(false);
  const [duplicateWarning, setDuplicateWarning] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");

  const {
    register,
    handleSubmit,
    watch,
    setValue,
    formState: { errors },
  } = useForm<CheckoutForm>({
    resolver: zodResolver(checkoutSchema),
    defaultValues: { payment_method: "bkash" },
  });

  const selectedMethod = watch("payment_method");

  const onSubmit = async (data: CheckoutForm) => {
    setSubmitting(true);
    setErrorMsg("");
    setDuplicateWarning(false);

    try {
      // Check duplicate transaction_id
      const { data: existingPayments } = await supabase
        .from("payments")
        .select("id")
        .eq("transaction_id", data.transaction_id)
        .limit(1);

      if (existingPayments && existingPayments.length > 0) {
        setDuplicateWarning(true);
      }

      // Get product
      const { data: product, error: productErr } = await supabase
        .from("products")
        .select("id")
        .eq("slug", "customer-psychology")
        .single();

      if (productErr || !product) throw new Error("প্রোডাক্ট পাওয়া যায়নি");

      // Upsert customer
      let customerId: string;
      const { data: existingCustomer } = await supabase
        .from("customers")
        .select("id")
        .eq("email", data.email)
        .single();

      if (existingCustomer) {
        customerId = existingCustomer.id;
      } else {
        const { data: newCustomer, error: custErr } = await supabase
          .from("customers")
          .insert({ full_name: data.full_name, email: data.email, phone: data.phone })
          .select("id")
          .single();
        if (custErr || !newCustomer) throw new Error("কাস্টমার তৈরি করা যায়নি");
        customerId = newCustomer.id;
      }

      // Create order
      const { data: order, error: orderErr } = await supabase
        .from("orders")
        .insert({
          customer_id: customerId,
          product_id: product.id,
          full_name: data.full_name,
          email: data.email,
          phone: data.phone,
          payment_method: data.payment_method,
          transaction_id: data.transaction_id,
          amount: 279.0,
          status: "pending",
        })
        .select("id, order_number")
        .single();

      if (orderErr || !order) throw new Error("অর্ডার তৈরি করা যায়নি");

      // Create payment
      await supabase.from("payments").insert({
        order_id: order.id,
        customer_id: customerId,
        method: data.payment_method,
        transaction_id: data.transaction_id,
        amount: 279.0,
        status: "pending",
      });


      navigate(`/thank-you?order=${order.order_number}`);
    } catch (err: any) {
      setErrorMsg(err?.message || "কিছু সমস্যা হয়েছে। আবার চেষ্টা করুন।");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-background py-12 px-4">
      <div className="container max-w-xl mx-auto space-y-8">
        <h1 className="text-3xl md:text-4xl font-bold text-center">
          অর্ডার <span className="text-primary">করুন</span>
        </h1>

        {/* Payment Instructions */}
        <div className="bg-card rounded-xl p-6 border border-primary/10 space-y-4">
          <h2 className="text-xl font-bold text-primary">পেমেন্ট নির্দেশনা</h2>
          <div className="space-y-3 text-foreground/90">
            <p>১. নিচের যেকোনো একটি নম্বরে <strong>Send Money</strong> করুন:</p>
            <div className="space-y-2 pl-4">
              <p>🟢 বিকাশ: <span className="font-inter font-semibold text-primary">{paymentNumbers.bkash}</span></p>
              <p>🟠 নগদ: <span className="font-inter font-semibold text-primary">{paymentNumbers.nagad}</span></p>
              <p>🟣 রকেট: <span className="font-inter font-semibold text-primary">{paymentNumbers.rocket}</span></p>
            </div>
            <p>২. Amount: <span className="font-inter font-bold text-primary">৳279</span></p>
            <p>৩. Send Money করার পর নিচের ফর্মে Transaction ID দিন।</p>
          </div>
        </div>

        {/* Order Form */}
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-5">
          <div className="space-y-2">
            <Label htmlFor="full_name">আপনার নাম</Label>
            <Input id="full_name" placeholder="পুরো নাম লিখুন" {...register("full_name")} className="bg-card border-primary/20 text-foreground" />
            {errors.full_name && <p className="text-destructive text-sm">{errors.full_name.message}</p>}
          </div>

          <div className="space-y-2">
            <Label htmlFor="email">ইমেইল</Label>
            <Input id="email" type="email" placeholder="example@email.com" {...register("email")} className="bg-card border-primary/20 text-foreground font-inter" />
            {errors.email && <p className="text-destructive text-sm">{errors.email.message}</p>}
          </div>

          <div className="space-y-2">
            <Label htmlFor="phone">ফোন নম্বর</Label>
            <Input id="phone" placeholder="01XXXXXXXXX" {...register("phone")} className="bg-card border-primary/20 text-foreground font-inter" />
            {errors.phone && <p className="text-destructive text-sm">{errors.phone.message}</p>}
          </div>

          <div className="space-y-2">
            <Label>পেমেন্ট মেথড</Label>
            <RadioGroup
              value={selectedMethod}
              onValueChange={(v) => setValue("payment_method", v as any)}
              className="flex gap-6"
            >
              {(["bkash", "nagad", "rocket"] as const).map((m) => (
                <div key={m} className="flex items-center gap-2">
                  <RadioGroupItem value={m} id={m} />
                  <Label htmlFor={m} className="cursor-pointer capitalize font-inter">
                    {m === "bkash" ? "বিকাশ" : m === "nagad" ? "নগদ" : "রকেট"}
                  </Label>
                </div>
              ))}
            </RadioGroup>
            {errors.payment_method && <p className="text-destructive text-sm">{errors.payment_method.message}</p>}
          </div>

          <div className="space-y-2">
            <Label htmlFor="transaction_id">Transaction ID</Label>
            <Input id="transaction_id" placeholder="Transaction ID লিখুন" {...register("transaction_id")} className="bg-card border-primary/20 text-foreground font-inter" />
            {errors.transaction_id && <p className="text-destructive text-sm">{errors.transaction_id.message}</p>}
            {duplicateWarning && (
              <p className="text-urgency text-sm">
                ⚠️ এই Transaction ID টি আগে ব্যবহার করা হয়েছে। সঠিক ID দিন।
              </p>
            )}
          </div>

          {errorMsg && (
            <div className="bg-destructive/10 border border-destructive/30 rounded-lg p-4 text-destructive text-sm">
              {errorMsg}
            </div>
          )}

          <GoldCTA type="submit" size="lg" className="w-full" disabled={submitting}>
            {submitting ? "অপেক্ষা করুন..." : "অর্ডার কনফার্ম করুন"}
          </GoldCTA>
        </form>
      </div>
    </div>
  );
}
